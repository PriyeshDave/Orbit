import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { useSession } from "../context/SessionContext.jsx";
import { Avatar } from "../components/AppShell.jsx";

export default function Login() {
  const [personas, setPersonas] = useState([]);
  const [loadingId, setLoadingId] = useState(null);
  const [error, setError] = useState(null);
  const { login } = useSession();
  const navigate = useNavigate();

  useEffect(() => {
    api
      .listPersonas()
      .then((res) => setPersonas(res.personas))
      .catch((e) => setError(e.message));
  }, []);

  async function handleLogin(personaId) {
    setLoadingId(personaId);
    setError(null);
    try {
      await login(personaId);
      navigate("/");
    } catch (e) {
      setError(e.message);
    } finally {
      setLoadingId(null);
    }
  }

  return (
    <div
      style={{
        height: "100vh", width: "100vw", display: "flex",
        alignItems: "center", justifyContent: "center", background: "var(--surface-canvas)",
      }}
    >
      <div style={{ width: 520, textAlign: "center" }}>
        <div
          style={{
            width: 56, height: 56, borderRadius: "var(--radius-lg)",
            background: "linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))",
            margin: "0 auto 20px", display: "flex", alignItems: "center", justifyContent: "center",
            color: "#fff", fontWeight: 700, fontSize: 22,
          }}
        >
          FD
        </div>
        <h1 style={{ fontSize: 24, fontWeight: 600, margin: "0 0 4px" }}>Flight Deck</h1>
        <h2 style={{ fontSize: 15, fontWeight: 500, margin: "0 0 20px", color: "var(--text-secondary)" }}>
          Catch up. Plan your day. Know if you're ready. One workspace, Digital Workplace team.
        </h2>

        <div style={{ color: "var(--text-secondary)", margin: "0 0 28px" }}>
          <p style={{ fontSize: 14, margin: 0 }}>
            Sign in to continue. This demo simulates Microsoft 365 authentication by letting you choose a colleague persona.
          </p>
        </div>

        {error && (
          <div
            style={{
              background: "var(--danger-tint)", color: "var(--danger)", padding: "10px 14px",
              borderRadius: "var(--radius-md)", fontSize: 13, marginBottom: 16, textAlign: "left",
            }}
          >
            {error}
          </div>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 8, textAlign: "left", maxHeight: 420, overflowY: "auto" }}>
          {personas.map((p) => (
            <button
              key={p.id}
              onClick={() => handleLogin(p.id)}
              disabled={loadingId !== null}
              style={{
                display: "flex", alignItems: "center", gap: 12, padding: "12px 14px",
                border: "1px solid var(--border-default)", borderRadius: "var(--radius-md)",
                background: "var(--surface-card)", cursor: loadingId ? "default" : "pointer",
                opacity: loadingId && loadingId !== p.id ? 0.5 : 1,
                transition: "border-color 120ms ease, background 120ms ease",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.borderColor = "var(--accent-primary)")}
              onMouseLeave={(e) => (e.currentTarget.style.borderColor = "var(--border-default)")}
            >
              <Avatar name={p.name} color={p.avatar_color} avatarUrl={`/avatars/${p.id}.svg`} size={36} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{p.name}</div>
                <div style={{ fontSize: 12, color: "var(--text-secondary)" }}>{p.role}</div>
              </div>
              {p.connected_tools && (
                <div style={{ fontSize: 10.5, color: "var(--text-tertiary)", flexShrink: 0 }}>
                  {p.connected_tools.length}/4 tools
                </div>
              )}
              {loadingId === p.id && (
                <div style={{ fontSize: 12, color: "var(--text-tertiary)" }}>Signing in…</div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
