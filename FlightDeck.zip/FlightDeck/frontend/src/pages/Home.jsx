import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { useSession } from "../context/SessionContext.jsx";

function Card({ title, accent, children, cta, onCta }) {
  return (
    <div
      style={{
        border: "1px solid var(--border-default)", borderRadius: "var(--radius-lg)",
        padding: 24, background: "var(--surface-card)", display: "flex", flexDirection: "column",
        gap: 12, minHeight: 220,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 8, height: 8, borderRadius: "50%", background: accent }} />
        <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>{title}</h3>
      </div>
      <div style={{ flex: 1, fontSize: 13.5, color: "var(--text-secondary)", lineHeight: 1.5 }}>{children}</div>
      <button
        onClick={onCta}
        style={{
          alignSelf: "flex-start", background: accent, color: "#fff", border: "none",
          borderRadius: "var(--radius-md)", padding: "8px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer",
        }}
      >
        {cta}
      </button>
    </div>
  );
}

export default function Home() {
  const { session } = useSession();
  const navigate = useNavigate();
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.homeSummary(session.sessionToken).then(setSummary).catch((e) => setError(e.message));
  }, [session.sessionToken]);

  return (
    <div style={{ padding: "32px 40px", maxWidth: 1100 }}>
      <div style={{ color: "var(--text-secondary)", fontSize: 13, marginBottom: 4 }}>
        Signed in as <strong>{session.name}</strong> · {session.role}
      </div>
      <h1 style={{ fontSize: 26, fontWeight: 700, margin: "0 0 6px" }}>Good to see you</h1>
      <p style={{ color: "var(--text-secondary)", fontSize: 14, margin: "0 0 28px" }}>
        One workspace for catching up, planning your day, and checking project readiness.
      </p>

      {error && (
        <div style={{ background: "var(--danger-tint)", color: "var(--danger)", padding: "10px 14px", borderRadius: "var(--radius-md)", fontSize: 13, marginBottom: 20 }}>
          {error}
        </div>
      )}

      {!summary && !error && <div style={{ color: "var(--text-tertiary)", fontSize: 13 }}>Loading your day...</div>}

      {summary && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20 }}>
          <Card
            title="Catch Up"
            accent="var(--accent-primary)"
            cta="Open Catch Up"
            onCta={() => navigate("/catchup")}
          >
            <p style={{ margin: "0 0 8px" }}>
              You're on the invite list for <strong>{summary.catchup.eligible_meeting_count}</strong> meeting
              {summary.catchup.eligible_meeting_count === 1 ? "" : "s"}.
            </p>
            {summary.catchup.meetings.slice(0, 3).map((m) => (
              <div key={m.id} style={{ fontSize: 12.5, marginBottom: 3 }}>
                {m.has_run ? "✓" : "•"} {m.title}
              </div>
            ))}
          </Card>

          <Card
            title="Daily Plan"
            accent="var(--accent-secondary)"
            cta={summary.planner.has_plan ? "View Plan" : "Build Today's Plan"}
            onCta={() => navigate("/planner")}
          >
            <p style={{ margin: "0 0 8px" }}>
              <strong>{summary.planner.connected_tools.length}/4</strong> tools connected: {summary.planner.connected_tools.join(", ") || "none"}.
            </p>
            {summary.planner.has_plan ? (
              <p style={{ margin: 0 }}>Top priority: <strong>{summary.planner.top_priority}</strong></p>
            ) : (
              <p style={{ margin: 0, fontStyle: "italic" }}>No plan generated yet today.</p>
            )}
          </Card>

          <Card
            title="Readiness"
            accent="var(--danger)"
            cta="Ask Readiness"
            onCta={() => navigate("/readiness")}
          >
            <p style={{ margin: "0 0 8px" }}>
              Tracking: <strong>{summary.readiness.tracked_project}</strong>
            </p>
            <p style={{ margin: 0 }}>{summary.readiness.milestone}</p>
          </Card>
        </div>
      )}
    </div>
  );
}
