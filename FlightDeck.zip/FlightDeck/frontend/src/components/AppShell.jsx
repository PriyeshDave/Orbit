import { useState } from "react";
import { useNavigate, useLocation, useParams } from "react-router-dom";
import { useSession } from "../context/SessionContext.jsx";

export function Avatar({ name, color, size = 32, avatarUrl }) {
  const initials = name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
  const [imgFailed, setImgFailed] = useState(false);
  const showImage = avatarUrl && !imgFailed;

  return (
    <div
      style={{
        width: size, height: size, borderRadius: "50%", background: color, color: "#fff",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontWeight: 600, fontSize: size * 0.38, flexShrink: 0, overflow: "hidden",
      }}
      title={name}
    >
      {showImage ? (
        <img
          src={avatarUrl} alt={name} width={size} height={size}
          style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
          onError={() => setImgFailed(true)}
        />
      ) : (
        initials
      )}
    </div>
  );
}

function NavIcon({ label, symbol, active, onClick }) {
  return (
    <button
      onClick={onClick}
      title={label}
      style={{
        width: 44, height: 44, borderRadius: "var(--radius-md)",
        border: "none",
        background: active ? "var(--accent-primary-tint)" : "transparent",
        color: active ? "var(--accent-primary)" : "var(--text-secondary)",
        fontWeight: 700, fontSize: 14, cursor: "pointer",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}
    >
      {symbol}
    </button>
  );
}

export default function AppShell({ children }) {
  const { session, logout } = useSession();
  const navigate = useNavigate();
  const location = useLocation();
  const params = useParams();

  const path = location.pathname;
  const inCatchupMeeting = path.startsWith("/catchup/meeting/");
  const onCatchupSystemFlow = path.endsWith("/system-flow") && inCatchupMeeting;
  const inPlanner = path.startsWith("/planner");
  const onPlannerSystemFlow = path === "/planner/system-flow";
  const inReadiness = path.startsWith("/readiness");
  const onReadinessFlow = path === "/readiness/flow";

  return (
    <div style={{ display: "flex", height: "100%", width: "100%" }}>
      {/* Left nav rail */}
      <div
        style={{
          width: "var(--nav-width)", flexShrink: 0, borderRight: "1px solid var(--border-default)",
          display: "flex", flexDirection: "column", alignItems: "center", padding: "16px 0", gap: 8,
        }}
      >
        <div
          style={{
            width: 40, height: 40, borderRadius: "var(--radius-md)", background: "var(--accent-primary)",
            color: "#fff", display: "flex", alignItems: "center", justifyContent: "center",
            fontWeight: 700, fontSize: 15, marginBottom: 12,
          }}
          title="Flight Deck"
        >
          FD
        </div>

        <NavIcon label="Home" symbol="H" active={path === "/"} onClick={() => navigate("/")} />
        <NavIcon label="Catch Up" symbol="C" active={path.startsWith("/catchup")} onClick={() => navigate("/catchup")} />
        <NavIcon label="Daily Plan" symbol="P" active={inPlanner} onClick={() => navigate("/planner")} />
        <NavIcon label="Readiness" symbol="R" active={inReadiness} onClick={() => navigate("/readiness")} />

        {inCatchupMeeting && (
          <>
            <div style={{ height: 1, width: 28, background: "var(--border-default)", margin: "4px 0" }} />
            <NavIcon label="Assistant" symbol="A" active={!onCatchupSystemFlow} onClick={() => navigate(`/catchup/meeting/${params.meetingId}`)} />
            <NavIcon label="System Flow" symbol="F" active={onCatchupSystemFlow} onClick={() => navigate(`/catchup/meeting/${params.meetingId}/system-flow`)} />
          </>
        )}

        {inPlanner && (
          <>
            <div style={{ height: 1, width: 28, background: "var(--border-default)", margin: "4px 0" }} />
            <NavIcon label="System Flow" symbol="F" active={onPlannerSystemFlow} onClick={() => navigate("/planner/system-flow")} />
          </>
        )}

        {inReadiness && (
          <>
            <div style={{ height: 1, width: 28, background: "var(--border-default)", margin: "4px 0" }} />
            <NavIcon label="Flow" symbol="F" active={onReadinessFlow} onClick={() => navigate("/readiness/flow")} />
          </>
        )}

        <div style={{ flex: 1 }} />

        {session && (
          <div onClick={logout} title={`${session.name} - sign out`} style={{ cursor: "pointer" }}>
            <Avatar name={session.name} color={session.avatarColor} avatarUrl={`/avatars/${session.personaId}.svg`} />
          </div>
        )}
      </div>

      {/* Main column */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0, overflow: "auto" }}>
        {children}
      </div>
    </div>
  );
}
