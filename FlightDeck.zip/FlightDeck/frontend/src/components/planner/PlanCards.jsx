import { TOOLS, URGENCY_COLOR, URGENCY_TINT } from "./toolMeta.js";

export default function PlanCards({ plan }) {
  if (!plan || plan.length === 0) {
    return (
      <div style={{ color: "var(--text-tertiary)", fontSize: 13, padding: "32px 0", textAlign: "center" }}>
        Choose a time of day and ask for your plan to see prioritized items here.
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {plan
        .slice()
        .sort((a, b) => a.rank - b.rank)
        .map((item, i) => {
          const tool = TOOLS.find((t) => t.key === item.source_tool);
          return (
            <div
              key={i}
              style={{
                border: "1px solid var(--border-default)",
                borderRadius: "var(--radius-md)",
                padding: "14px 16px",
                background: "var(--surface-card)",
                boxShadow: "var(--shadow-sm)",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
                <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                  <div
                    style={{
                      width: 24,
                      height: 24,
                      borderRadius: "50%",
                      background: "var(--surface-sunken)",
                      color: "var(--text-secondary)",
                      fontSize: 12,
                      fontWeight: 700,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    {item.rank}
                  </div>
                  <div>
                    <div style={{ fontSize: 14.5, fontWeight: 600 }}>{item.title}</div>
                    <div style={{ fontSize: 12.5, color: "var(--text-secondary)", marginTop: 3 }}>{item.why}</div>
                  </div>
                </div>
                <span
                  style={{
                    fontSize: 10.5,
                    fontWeight: 700,
                    textTransform: "uppercase",
                    color: URGENCY_COLOR[item.urgency] || "var(--text-secondary)",
                    background: URGENCY_TINT[item.urgency] || "var(--surface-sunken)",
                    padding: "3px 9px",
                    borderRadius: 20,
                    whiteSpace: "nowrap",
                    flexShrink: 0,
                  }}
                >
                  {item.urgency}
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10, paddingLeft: 34 }}>
                <span
                  style={{
                    fontSize: 11,
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    color: "var(--text-tertiary)",
                  }}
                >
                  <span style={{ width: 7, height: 7, borderRadius: "50%", background: tool?.color || "#999" }} />
                  {tool?.label || item.source_tool}
                </span>
                <span style={{ fontSize: 12, color: "var(--accent-primary)", fontWeight: 600 }}>
                  {item.suggested_action}
                </span>
              </div>
            </div>
          );
        })}
    </div>
  );
}
