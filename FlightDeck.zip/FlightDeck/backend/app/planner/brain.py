"""
The Planner orchestration "brain" - discover which tools are connected,
fan out real MCP calls to each connected tool in parallel, feed everything
gathered into ONE reasoning LLM call that produces a prioritized,
time-of-day-aware plan.

Not a multi-agent system: one orchestrator, one reasoning call, N parallel
tool calls via the real MCP protocol. The parallelism comes essentially
for free because of MCP's uniform interface - no bespoke code per tool.
"""
import asyncio
import json
import time
from pathlib import Path
from typing import AsyncGenerator

from app.shared import auth as mock_auth
from app.planner.schemas import (
    ConnectorEvent, MCPCallTelemetry, PlanItem, PlanRunLogResponse, PlanRunSummary, ReasoningEvent,
)
from app.planner import state as run_state
from app.planner.mcp_client_manager import query_connector
from app.shared.telemetry import build_telemetry, langsmith_project_url, wrap_traceable
from app.shared.openai_client import call_llm

PROMPTS_DIR = Path(__file__).resolve().parent / "prompts"
DATA_DIR = Path(__file__).resolve().parent.parent / "data"

ALL_TOOLS = ["outlook", "teams", "slack", "tracker"]

SYSTEM_PROMPT = (
    "You are a precise, factual work-planning assistant. You never invent facts not "
    "present in the provided tool data. When asked for JSON, you return ONLY valid JSON "
    "with no markdown code fences and no extra commentary."
)


def _load_clock() -> dict:
    with open(DATA_DIR / "simulated_clock.json", "r", encoding="utf-8") as f:
        return json.load(f)


def _load_prompt(name: str) -> str:
    with open(PROMPTS_DIR / f"{name}.txt", "r", encoding="utf-8") as f:
        return f.read()


def _safe_json_parse(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        return {"plan": [], "_parse_warning": "Model output could not be parsed as JSON."}


async def run_plan(persona_id: str, time_of_day: str, free_text: str | None = None) -> AsyncGenerator[ConnectorEvent | ReasoningEvent, None]:
    wall_clock_start = time.perf_counter()

    connected = set(mock_auth.connected_tools(persona_id))
    clock = _load_clock()
    as_of = clock["as_of"][time_of_day]

    connector_events: list[ConnectorEvent] = []
    tool_data: dict[str, dict] = {}
    total_mcp_latency_ms = 0

    tasks: dict[str, asyncio.Task] = {}
    for tool in ALL_TOOLS:
        if tool not in connected:
            ev = ConnectorEvent(tool=tool, status="skipped")
            connector_events.append(ev)
            yield ev
            continue
        yield ConnectorEvent(tool=tool, status="running")
        tasks[tool] = asyncio.create_task(query_connector(tool, persona_id, as_of))

    for tool, task in tasks.items():
        try:
            data, latency_ms, tool_names_called = await task
            tool_data[tool] = data
            total_mcp_latency_ms += latency_ms
            telem = MCPCallTelemetry(tool=tool, tool_name=tool_names_called, latency_ms=latency_ms, connected=True)
            ev = ConnectorEvent(tool=tool, status="done", telemetry=telem)
        except Exception as e:  # noqa: BLE001 - demo-grade: surface any MCP failure to the UI
            ev = ConnectorEvent(tool=tool, status="error", error=str(e))
        connector_events.append(ev)
        yield ev

    yield ReasoningEvent(status="running")

    optional_free_text_instruction = (
        f'The user also asked, in their own words: "{free_text}". Take this into account when ranking and framing the plan.'
        if free_text else ""
    )

    prompt = _load_prompt("synthesize_plan").format(
        as_of=as_of, time_of_day=time_of_day,
        optional_free_text_instruction=optional_free_text_instruction,
        tool_data_json=json.dumps(tool_data, indent=2),
    )

    def _inner():
        return call_llm(system_prompt=SYSTEM_PROMPT, user_prompt=prompt)

    traced = wrap_traceable(name="synthesize_plan", fn=_inner)
    result = traced()

    parsed = _safe_json_parse(result.text)
    raw_plan = parsed.get("plan", [])
    telem = build_telemetry("synthesize_plan", result)

    plan_items: list[PlanItem] = []
    for item in raw_plan:
        try:
            plan_items.append(PlanItem(**item))
        except Exception:  # noqa: BLE001 - skip malformed individual items rather than fail the run
            continue

    reasoning_event = ReasoningEvent(status="done", output=raw_plan, telemetry=telem)
    yield reasoning_event

    wall_clock_ms = int((time.perf_counter() - wall_clock_start) * 1000)
    summary = PlanRunSummary(
        persona_id=persona_id, time_of_day=time_of_day,
        tools_connected=len(connected), tools_total=len(ALL_TOOLS),
        total_wall_clock_ms=wall_clock_ms, total_mcp_latency_ms=total_mcp_latency_ms,
        total_llm_latency_ms=telem.latency_ms, total_tokens=telem.total_tokens,
        total_cost_usd=telem.cost_usd, langsmith_enabled=telem.langsmith_enabled,
        langsmith_project=langsmith_project_url(),
    )
    run_state.save_run(
        persona_id,
        PlanRunLogResponse(
            persona_id=persona_id, time_of_day=time_of_day,
            connectors=connector_events, reasoning=reasoning_event,
            plan=plan_items, summary=summary,
        ),
    )
