"""In-memory store for the last plan run per persona - process-local, demo-scoped."""
from typing import Optional

from app.planner.schemas import PlanRunLogResponse

_last_run_by_persona: dict[str, PlanRunLogResponse] = {}


def save_run(persona_id: str, run_log: PlanRunLogResponse) -> None:
    _last_run_by_persona[persona_id] = run_log


def get_last_run(persona_id: str) -> Optional[PlanRunLogResponse]:
    return _last_run_by_persona.get(persona_id)
